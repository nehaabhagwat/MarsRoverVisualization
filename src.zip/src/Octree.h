#pragma once
#ifndef Octree_h
#define Octree_h
#endif /* Octree_h */

#include "box.h"
#include <vector>

using namespace std;

class Octree{
public:
    Box box;
	Octree* children[8];
	vector<int> points;
};