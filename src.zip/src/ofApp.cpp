
//--------------------------------------------------------------
//
//  Mars HiRise Project - startup scene
//
//  This is an openFrameworks 3D scene that includes an EasyCam
//  and example 3D geometry which I have reconstructed from Mars
//  HiRis photographs taken the Mars Reconnaisance Orbiter
//
//  You will use this source file (and include file) as a starting point
//  to implement assignment 5  (Parts I and II)
//
//  Please do not modify any of the keymappings.  I would like
//  the input interface to be the same for each student's
//  work.  Please also add your name/date below.

//  Please document/comment all of your work !
//  Have Fun !!
//
//  Student Name: Neha Bhagwat
//  Date: May 16th, 2018


#include "ofApp.h"
#include "Util.h"
#include "Windows.h"



//--------------------------------------------------------------
// setup scene, lighting, state and load geometry
//
void ofApp::setup(){
    
    bWireframe = false;
    bDisplayPoints = false;
    bAltKeyDown = false;
    bCtrlKeyDown = false;
    bRoverLoaded = false;
    bTerrainSelected = true;
	bRetargetCamera = false;
    //    ofSetWindowShape(1024, 768);
    cam.setDistance(10);
    cam.setNearClip(.1);
    cam.setFov(65.5);   // approx equivalent to 28mm in 35mm format
    ofSetVerticalSync(true);
    cam.disableMouseInput();
    ofEnableSmoothing();
    ofEnableDepthTest();
    
    // setup rudimentary lighting
    //
    initLightingAndMaterials();
    
    mars.loadModel("geo/mars-low-v2.obj");
    mars.setScaleNormalization(false);
    
    createOctree();
    
	polylinePoints.clear();
	path.clear();
	//gui.setup();
	//gui.setPosition(cam.screenToWorld(ofVec2f(-50 , 0)));
	//gui.add(speedSlider.setup("speed", 0, 10, 90));
	//speedSlider.setSize(0.05,0.20);
}

//--------------------------------------------------------------
void ofApp::createOctree(){
    ofMesh m = mars.getMesh(0);
    boundingBox = meshBounds(m);
    cout<<"\nBounding box";
    root = new Octree();
    root->box = boundingBox;
    cout<<"\nRoot set";
    for(int i = 0;i<8;i++)
        root->children[i] = NULL;
    pointsList = m.getVertices();
    for(int i=0;i<pointsList.size();i++)
        root->points.push_back(i);
    cur = root;
	float startTime = ofGetElapsedTimef();
    subdivideTree(cur);
	float endTime = ofGetElapsedTimef();
	cout << "\nTime required for Octree creation: " << (endTime - startTime) << "\n";
    // displayTree(cur);
    
}

//--------------------------------------------------------------
void ofApp::displayTree(Octree* head){
	cout << head->points.size() << "\n";
	cout << head->box.parameters[0].x() << ", " << head->box.parameters[0].y();
    if(head == NULL){
        cout<<"\nEmpty tree";
		return;
    }
    
    displayTree(head->children[0]);
    displayTree(head->children[1]);
    displayTree(head->children[2]);
    displayTree(head->children[3]);
    displayTree(head->children[4]);
    displayTree(head->children[5]);
    displayTree(head->children[6]);
    displayTree(head->children[7]);
}

//--------------------------------------------------------------
// incrementally update scene (animation)
//
void ofApp::update() {
	
	if (bPlay == true) {
		if (roverIndex < path.size()) {
			// cout << "\nDrawing rover at: " << roverIndex;
			rover.setScaleNormalization(false);
			rover.setScale(.005, .005, .005);
			if (roverIndex > 1 && roverIndex < path.size() - 1) {
				ofVec3f v2 = path[roverIndex] - path[roverIndex - 1];
				ofVec3f v1 = path[roverIndex + 1] - path[roverIndex];
				angle = path.getAngleAtIndex(roverIndex - 1);
				// angle = (v2).angle(v1);
				ofVec3f normalized = (v2).cross(v1).getNormalized();
				if (normalized.z <= 0) {
					angle = -angle;
				}
				
				int num = rover.getNumRotations();
				rover.setRotation(num+1, angle, 0, 1, 0);
			}
			ofVec3f lastPos = rover.getPosition();
			ofVec3f diff = path[roverIndex] - lastPos;
			rover.setPosition(path[roverIndex].x, path[roverIndex].y, path[roverIndex].z);
			// ofVec3f min = 0.005 * rover.getSceneMin();
			// ofVec3f max = 0.005 * rover.getSceneMax();
			roverBound.parameters[0] = roverBound.parameters[0] + Vector3(diff.x, diff.y, diff.z);
			roverBound.parameters[1] = roverBound.parameters[1] + Vector3(diff.x, diff.y, diff.z);
			bRoverLoaded = true;
			bRoverSelected = false;
			RoverLocation = rover.getPosition();
			roverCam.setPosition(RoverLocation.x, RoverLocation.y + 10, RoverLocation.z);
			roverCam.lookAt(ofVec3f(RoverLocation.x, RoverLocation.y + 5, RoverLocation.z));
			// backCam.setPosition(RoverLocation.x, RoverLocation.y, RoverLocation.z);
			// backCam.lookAt(ofVec3f(RoverLocation.x + 3, RoverLocation.y , RoverLocation.z));
			backCam.setPosition(RoverLocation.x, RoverLocation.y+2, RoverLocation.z);
			backCam.setNearClip(.1);
			backCam.setFov(65.5);
			frontCam.setPosition(RoverLocation.x, RoverLocation.y + 2, RoverLocation.z);
			frontCam.lookAt(ofVec3f(RoverLocation.x, RoverLocation.y, RoverLocation.z + 5));
			frontCam.setNearClip(.1);
			frontCam.setFov(65.5);
			frontCamPosition = frontCam.getPosition();
			backCamPosition = backCam.getPosition();
			frontCamLookAt = ofVec3f(RoverLocation.x, RoverLocation.y, RoverLocation.z + 5);
			// Sleep(20);

			roverIndex += 1;
		}
		else {
			roverIndex = 0;
			bPlay = false;
		}
	}
}
//--------------------------------------------------------------
void ofApp::draw(){
    
    //    ofBackgroundGradient(ofColor(20), ofColor(0));   // pick your own backgroujnd
    ofBackground(ofColor::black);
    //    cout << ofGetFrameRate() << endl;
    
	if (camera == 0)
		cam.begin();
	else if (camera == 1)
		roverCam.begin();
	else if (camera == 2)
		frontCam.begin();
	else
		backCam.begin();
	
    //cam.begin();
	// gui.draw();
    ofPushMatrix();
    if (bWireframe) {                    // wireframe mode  (include axis)
        ofDisableLighting();
        ofSetColor(ofColor::slateGray);
        mars.drawWireframe();
        if (bRoverLoaded) {
            rover.drawWireframe();
            if (!bTerrainSelected) drawAxis(rover.getPosition());
        }
        if (bTerrainSelected) drawAxis(ofVec3f(0, 0, 0));
    }
    else {
        ofEnableLighting();              // shaded mode
        mars.drawFaces();
        
        if (bRoverLoaded) {
            rover.drawFaces();
            if (!bTerrainSelected) drawAxis(rover.getPosition());
        }
        if (bTerrainSelected) drawAxis(ofVec3f(0, 0, 0));
    }
	if (bRoverSelected) {
		ofNoFill();
		ofSetColor(ofColor::white);
		drawBox(roverBound);
	}
    
    if (bDisplayPoints) {                // display points as an option
        glPointSize(3);
        ofSetColor(ofColor::green);
        mars.drawVertices();
    }
    
    // highlight selected point (draw sphere around selected point)
    //
    if (polylinePoints.size() > 0) { //bPointSelected
        ofSetColor(ofColor::blue);
        // ofDrawSphere(selectedPoint, .1);
		for (int i = 0; i < polylinePoints.size(); i++) {
			ofDrawSphere(polylinePoints[i], .1);
		}
		path.draw();
		ofSetColor(ofColor::yellow);
		if (bDisplayCoordinates == true) {
			for (int i = 0; i < polylinePoints.size(); i++) {
				// ofVec2f drawPoint = cam.worldToScreen(polylinePoints[i]);
				// ofDrawSphere(polylinePoints[i], .1);
				ofDrawBitmapString((to_string(polylinePoints[i].x) + ", " + to_string(polylinePoints[i].y) + ", " + to_string(polylinePoints[i].z)), polylinePoints[i].x, polylinePoints[i].y, polylinePoints[i].z);
			}
		}
    }

	/*ofSetColor(ofColor::purple);
	ofDrawSphere(frontCamPosition, 0.1);
	ofSetColor(ofColor::yellow);
	ofDrawSphere(frontCamLookAt, 0.1);
	ofSetColor(ofColor::green);
	ofDrawSphere(backCamPosition, 0.1);
    */
    ofNoFill();
    ofPopMatrix();
	if (camera == 0)
		cam.end();
	else if (camera == 1)
		roverCam.end();
	else if (camera == 2)
		frontCam.end();
	else
		backCam.end();
	
}

void ofApp::switchPerspective() {
	if (bRoverLoaded == true) {
		camera = (camera + 1) % 4;
	}
}

//

// Draw an XYZ axis in RGB at world (0,0,0) for reference.
//
void ofApp::drawAxis(ofVec3f location) {
    
    ofPushMatrix();
    ofTranslate(location);
    
    ofSetLineWidth(1.0);
    
    // X Axis
    ofSetColor(ofColor(255, 0, 0));
    ofDrawLine(ofPoint(0, 0, 0), ofPoint(1, 0, 0));
    
    
    // Y Axis
    ofSetColor(ofColor(0, 255, 0));
    ofDrawLine(ofPoint(0, 0, 0), ofPoint(0, 1, 0));
    
    // Z Axis
    ofSetColor(ofColor(0, 0, 255));
    ofDrawLine(ofPoint(0, 0, 0), ofPoint(0, 0, 1));
    
    ofPopMatrix();
}

void ofApp::saveToFile() {
	if (polylinePoints.size() > 0) {
		string p = "";
		for (int i = 0; i < polylinePoints.size(); i++) {
			p += to_string(polylinePoints[i].x) + ", " + to_string(polylinePoints[i].y) + ", " + to_string(polylinePoints[i].z) + "\n";
		}
		buffer.set(p.c_str(), p.size());
		ofFile outFile;
		outFile.open(ofToDataPath("points.txt"), ofFile::ReadWrite, false);
		outFile.close();
	}
}

void ofApp::setCameraTarget() {
	cam.setTarget(cameraTarget);
}

void ofApp::keyPressed(int key) {
    
    switch (key) {
        case 'C':
        case 'c':
            if (cam.getMouseInputEnabled()) cam.disableMouseInput();
            else cam.enableMouseInput();
            break;
        case 'F':
        case 'f':
            ofToggleFullscreen();
            break;
        case 'H':
        case 'h':
			switchPerspective();
            break;
		case 'm':
		case 'M':
			if (bDisplayCoordinates == false)
				bDisplayCoordinates = true;
			else
				bDisplayCoordinates = false;
			break;
		case 'p':
		case 'P':
			path = path.getResampledByCount(1000);
			cout << "Path size: " << path.size() << "\n";
			bPlay = true;
			break;
        case 'r':
            cam.reset();
            break;
		case 'S':
        case 's':
            savePicture();
            break;
        case 't':
			bRetargetCamera = true;
            setCameraTarget();
            break;
        case 'u':
			saveToFile();
            break;
        case 'v':
            togglePointsDisplay();
            break;
        case 'V':
            break;
        case 'w':
            toggleWireframeMode();
            break;
        case OF_KEY_ALT:
            cam.enableMouseInput();
            bAltKeyDown = true;
            break;
        case OF_KEY_CONTROL:
            bCtrlKeyDown = true;
            break;
        case OF_KEY_SHIFT:
			bShiftKeyDown = true;
            break;
        case OF_KEY_DEL:
            break;
		case OF_KEY_UP:
			if (bPlay == true) {
				int f = ofGetFrameRate();
				ofSetFrameRate(f + 30);
			}
			break;
		case OF_KEY_DOWN:
			if (bPlay == true) {
				int f = ofGetFrameRate();
				if (f>30)
					ofSetFrameRate(f - 30);
			}
			break;
        default:
            break;
    }
}

void ofApp::toggleWireframeMode() {
    bWireframe = !bWireframe;
}

void ofApp::toggleSelectTerrain() {
    bTerrainSelected = !bTerrainSelected;
}

void ofApp::togglePointsDisplay() {
    bDisplayPoints = !bDisplayPoints;
}

void ofApp::keyReleased(int key) {
    
    switch (key) {
            
        case OF_KEY_ALT:
            cam.disableMouseInput();
            bAltKeyDown = false;
            break;
        case OF_KEY_CONTROL:
            bCtrlKeyDown = false;
            break;
        case OF_KEY_SHIFT:
			bShiftKeyDown = false;
            break;
		case OF_KEY_UP:
			break;
		case OF_KEY_DOWN:
			break;
        default:
            break;
            
    }
}



//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
}


//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {
	float detectionTimeStart = ofGetElapsedTimef();
    ofVec3f mouse(mouseX, mouseY);
    ofVec3f rayPoint = cam.screenToWorld(mouse);
    ofVec3f rayDir = rayPoint - cam.getPosition();
    rayDir.normalize(); 
    Ray ray = Ray(Vector3(rayPoint.x, rayPoint.y, rayPoint.z),
    Vector3(rayDir.x, rayDir.y, rayDir.z));
	if (bAltKeyDown == false) {
		if (roverBound.intersect(ray, -100, 100)) {
			bRoverSelected = true;
			bTerrainSelected = false;
		}
		else if (boundingBox.intersect(ray, -100, 100)) {
			bRoverSelected = false;
			bTerrainSelected = true;
		}
		else {
			bRoverSelected = false;
			bTerrainSelected = false;
			return;
		}
	}
	if (bCtrlKeyDown == true && bShiftKeyDown == false) {
		cout << "Checking if point already exists.\n";
		if (polylinePoints.size() > 0) {
			for (int i = 0; i < pathBoxes.size(); i++) {
				cout << "Distance: " << mouse.distance(cam.worldToScreen(polylinePoints[i])) << "\n";
				// if (mouse.distance(cam.worldToScreen(polylinePoints[i])) < threshold) {
				if(pathBoxes[i].intersect(ray, -100, 100)){
					cout << "\nMouse inside point.\n";
					bExistingPointSelected = true;
					ExistingPointIndex = i;
					ExistingPoint = polylinePoints[i];
					break;
				}
			}
		}
		if (bExistingPointSelected == false) {
			ExistingPointIndex = -1;
			cout << "New point found.\n";
			bPointSelected = true;
			pts.clear();
			detectIntersection(ray, root);
			if (pts.size() > 0) {
				sortPoints();
			}
			cout << "\n";
			cout << "\nPolyline size: " << polylinePoints.size();
			cout << '\n';
		}
	}
	if (bCtrlKeyDown == true && bShiftKeyDown == true) {
		if (pathBoxes.size() > 0) {
			for (int i = 0; i < pathBoxes.size(); i++) {
				if (pathBoxes[i].intersect(ray, -100, 100)) {
					bDeletePointSelected = true;
					DeletePointIndex = i;
					DeletePoint = polylinePoints[i];
					break;
				}
			}
		}
	}

}

// -------------------------------------------------------------
void ofApp::detectIntersection(Ray r, Octree* node) {
	if (node->box.intersect(r, -100, 100)) {
		int i;
		int flag = 0;
		for (i = 0; i<8; i++) {
			if (node->children[i] == NULL) {
				flag = 1;
				break;
			}
		}
		if (flag == 1) {
			bPointSelected = true;
			Vector3 p = (node->box.parameters[1] - node->box.parameters[0]) / 2 + node->box.parameters[0];
			pts.push_back(ofVec3f(p.x(), p.y(), p.z()));
			return;
		}
		else {
			flag = 0;
			for (i = 0; i<8; i++) {
				if (node->children[i] != NULL && node->children[i]->points.size() > 0)
					detectIntersection(r, node->children[i]);
			}
		}
	}
}

void ofApp::sortPoints() {
	float distance = 0;
	for (int i = 0; i < pts.size(); i++) {
		ofVec3f point = cam.worldToCamera(pts[i]);
		float curDist = point.length();
		if (i == 0 || curDist < distance) {
			distance = curDist;
			selectedPoint = pts[i];
		}
	}
	if (bDeletePointSelected) {
		if (polylinePoints.size() != pathBoxes.size()) {
			return;
		}
		int i;
		for (i = DeletePointIndex; i < polylinePoints.size() - 1; i++) {
			polylinePoints[i] = polylinePoints[i + 1];
			pathBoxes[i] = pathBoxes[i + 1];
		}
		polylinePoints.pop_back();
		pathBoxes.pop_back();
		path.clear();
		for (i = 0; i < polylinePoints.size(); i++) {
			path.addVertex(polylinePoints[i]);
		}
		DeletePointIndex = -1;
		bDeletePointSelected = false;
	}
	else if (ExistingPointIndex > -1) {
		polylinePoints[ExistingPointIndex] = selectedPoint;
		Box b;
		b.parameters[0] = Vector3(selectedPoint.x - 0.1, selectedPoint.y - 0.1, selectedPoint.z - 0.1);
		b.parameters[1] = Vector3(selectedPoint.x + 0.1, selectedPoint.y + 0.1, selectedPoint.z + 0.1);
		pathBoxes[ExistingPointIndex] = b;
		path.clear();
		for (int i = 0; i<polylinePoints.size(); i++)
			path.addVertex(polylinePoints[i]);
	}
	else if (bRetargetCamera == true) {
		cameraTarget = selectedPoint;
		setCameraTarget();
	}
	else{
		cout << "\nSelected point: " << selectedPoint;
		polylinePoints.push_back(selectedPoint);
		Box b;
		b.parameters[0] = Vector3(selectedPoint.x - 0.1, selectedPoint.y - 0.1, selectedPoint.z - 0.1);
		b.parameters[1] = Vector3(selectedPoint.x + 0.1, selectedPoint.y + 0.1, selectedPoint.z + 0.1);
		pathBoxes.push_back(b);
		path.addVertex(selectedPoint);
		if (path.size() == 1) {
			if(bRoverLoaded == true)
				startPath.addVertex(path[0]);
		}
	}
}

void ofApp::findRoverPosition() {
	float distance = 0;
	for (int i = 0; i < pts.size(); i++) {
		ofVec3f point = cam.worldToCamera(pts[i]);
		float curDist = point.length();
		if (i == 0 || curDist < distance) {
			distance = curDist;
			selectedPoint = pts[i];
		}
	}
}
//draw a box from a "Box" class
void ofApp::drawBox(const Box &box) {
    Vector3 min = box.parameters[0];
    Vector3 max = box.parameters[1];
    Vector3 size = max - min;
    Vector3 center = size / 2 + min;
    ofVec3f p = ofVec3f(center.x(), center.y(), center.z());
    float w = size.x();
    float h = size.y();
    float d = size.z();
    ofDrawBox(p, w, h, d);
}

// return a Mesh Bounding Box for the entire Mesh
Box ofApp::meshBounds(const ofMesh & mesh) {
    int n = mesh.getNumVertices();
    ofVec3f v = mesh.getVertex(0);
    ofVec3f max = v;
    ofVec3f min = v;
    for (int i = 1; i < n; i++) {
        ofVec3f v = mesh.getVertex(i);
        
        if (v.x > max.x) max.x = v.x;
        else if (v.x < min.x) min.x = v.x;
        
        if (v.y > max.y) max.y = v.y;
        else if (v.y < min.y) min.y = v.y;
        
        if (v.z > max.z) max.z = v.z;
        else if (v.z < min.z) min.z = v.z;
    }
    return Box(Vector3(min.x, min.y, min.z), Vector3(max.x, max.y, max.z));
    
}


void ofApp::subdivideTree(Octree* node) {
	levelCounter += 1;
    Vector3 min = node->box.parameters[0];
    Vector3 max = node->box.parameters[1];
    Vector3 size = max - min;
    Vector3 center = size / 2 + min;
    float xdist = (max.x() - min.x()) / 2;
    float ydist = (max.y() - min.y()) / 2;
    float zdist = (max.z() - min.z()) / 2;
    Vector3 h = Vector3(0, ydist, 0);
    int i, j;
    for(int i=0;i<8;i++){
        node->children[i] = new Octree();
        for(int j=0;j<8;j++)
            node->children[i]->children[j] = NULL;
    }
    node->children[0]->box = Box(min, center);
    node->children[1]->box = Box(node->children[0]->box.min() + Vector3(xdist, 0, 0), node->children[0]->box.max() + Vector3(xdist, 0, 0));
    node->children[2]->box = Box(node->children[1]->box.min() + Vector3(0, 0, zdist), node->children[1]->box.max() + Vector3(0, 0, zdist));
    node->children[3]->box = Box(node->children[2]->box.min() + Vector3(-xdist, 0, 0), node->children[2]->box.max() + Vector3(-xdist, 0, 0));
   
    for (int i = 4; i < 8; i++) {
        node->children[i]->box = Box(node->children[i - 4]->box.min() + h, node->children[i - 4]->box.max() + h);
    }

    for(int i = 0;i<node->points.size();i++){
        for(j = 0;j<8;j++){
            if(node->children[j]->box.isPointInside(pointsList[node->points[i]].x, pointsList[node->points[i]].y, pointsList[node->points[i]].z)){
                node->children[j]->points.push_back(node->points[i]);
				break;
            }
        }
    }

    for(i = 0;i<8;i++){
		if (node->children[i]->points.size() > 1) {
			subdivideTree(node->children[i]);
		}
    }
	for (int i = 0; i < 8; i++) {
		boxList.push_back(node->children[i]->box);
		numOfBoxes += 1;
	}
}
//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {   
	if (bRoverSelected) {
		ofVec3f point;
		ofVec3f mouse(mouseX, mouseY);
		ofVec3f rayPoint = cam.screenToWorld(mouse);
		ofVec3f rayDir = rayPoint - cam.getPosition();
		rayDir.normalize();
		Ray ray = Ray(Vector3(rayPoint.x, rayPoint.y, rayPoint.z),
			Vector3(rayDir.x, rayDir.y, rayDir.z));
		detectIntersection(ray, root);
		findRoverPosition();
		point = selectedPoint;
		pts.clear();
		// rover.setPosition(point.x, point.y, point.z);
		rover.setScaleNormalization(false);
		rover.setScale(.005, .005, .005);
		fixedRover = point;
		oldRoverPosition = rover.getPosition();
		rover.setPosition(point.x, point.y, point.z);
		cout << "Rover Position: " << rover.getPosition() << "\n";
		ofVec3f diff = rover.getPosition() - oldRoverPosition;
		//ofVec3f min = point - 0.005 * rover.getSceneMin();
		//ofVec3f max = point - 0.005 * rover.getSceneMax();
		//diff = min.z - point.z;
		//cout << "Diff: " << diff << "\n"; 
		//min.z = min.z + diff;
		//max.z = max.z + diff;
		roverBound.parameters[0] = roverBound.parameters[0] + Vector3(diff.x, diff.y, diff.z);
		roverBound.parameters[1] = roverBound.parameters[1] + Vector3(diff.x, diff.y, diff.z);

		bRoverLoaded = true;
		bRoverSelected = true;
	}
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {
	if (bDeletePointSelected == true) {
		ofVec3f mouse(mouseX, mouseY);
		ofVec3f rayPoint = cam.screenToWorld(mouse);
		ofVec3f rayDir = rayPoint - cam.getPosition();
		rayDir.normalize();
		Ray ray = Ray(Vector3(rayPoint.x, rayPoint.y, rayPoint.z),
			Vector3(rayDir.x, rayDir.y, rayDir.z));
		detectIntersection(ray, root);
		if (pts.size()>0) {
			sortPoints();
		}
		bDeletePointSelected = false;
		DeletePointIndex = -1;
	}
	
	if (bExistingPointSelected == true) {
		ofVec3f mouse(mouseX, mouseY);
		ofVec3f rayPoint = cam.screenToWorld(mouse);
		ofVec3f rayDir = rayPoint - cam.getPosition();
		rayDir.normalize();
		Ray ray = Ray(Vector3(rayPoint.x, rayPoint.y, rayPoint.z),
			Vector3(rayDir.x, rayDir.y, rayDir.z));
		detectIntersection(ray, root);
		if (pts.size() > 0)
			sortPoints();
		else {
			polylinePoints[ExistingPointIndex] = ExistingPoint;
		}
	}
	bExistingPointSelected = false;
	ExistingPointIndex = -1;
}


//
//  Select Target Point on Terrain by comparing distance of mouse to
//  vertice points projected onto screenspace.
//  if a point is selected, return true, else return false;
//
bool ofApp::doPointSelection() {
    
    ofMesh mesh = mars.getMesh(0);
    int n = mesh.getNumVertices();
    float nearestDistance = 0;
    int nearestIndex = 0;
    
    bPointSelected = false;
    
    ofVec2f mouse(mouseX, mouseY);
    vector<ofVec3f> selection;
    
    // We check through the mesh vertices to see which ones
    // are "close" to the mouse point in screen space.  If we find
    // points that are close, we store them in a vector (dynamic array)
    //
    for (int i = 0; i < n; i++) {
        ofVec3f vert = mesh.getVertex(i);
        ofVec3f posScreen = cam.worldToScreen(vert);
        float distance = posScreen.distance(mouse);
        if (distance < selectionRange) {
            selection.push_back(vert);
            bPointSelected = true;
        }
    }
    
    //  if we found selected points, we need to determine which
    //  one is closest to the eye (camera). That one is our selected target.
    //
    if (bPointSelected) {
        float distance = 0;
        for (int i = 0; i < selection.size(); i++) {
            ofVec3f point =  cam.worldToCamera(selection[i]);
            
            // In camera space, the camera is at (0,0,0), so distance from
            // the camera is simply the length of the point vector
            //
            float curDist = point.length();
            
            if (i == 0 || curDist < distance) {
                distance = curDist;
                selectedPoint = selection[i];
            }
        }
    }
    return bPointSelected;
}


//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}



//--------------------------------------------------------------
// setup basic ambient lighting in GL  (for now, enable just 1 light)
//
void ofApp::initLightingAndMaterials() {
    
    static float ambient[] =
    { .5f, .5f, .5, 1.0f };
    static float diffuse[] =
    { 1.0f, 1.0f, 1.0f, 1.0f };
    
    static float position[] =
    {5.0, 5.0, 5.0, 0.0 };
    
    static float lmodel_ambient[] =
    { 1.0f, 1.0f, 1.0f, 1.0f };
    
    static float lmodel_twoside[] =
    { GL_TRUE };
    
    
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
    glLightfv(GL_LIGHT0, GL_POSITION, position);
    
    glLightfv(GL_LIGHT1, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse);
    glLightfv(GL_LIGHT1, GL_POSITION, position);
    
    
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);
    glLightModelfv(GL_LIGHT_MODEL_TWO_SIDE, lmodel_twoside);
    
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    //    glEnable(GL_LIGHT1);
    glShadeModel(GL_SMOOTH);
}

void ofApp::savePicture() {
    ofImage picture;
    picture.grabScreen(0, 0, ofGetWidth(), ofGetHeight());
    picture.save("screenshot.png");
    cout << "picture saved" << endl;
}

//--------------------------------------------------------------
//
// support drag-and-drop of model (.obj) file loading.  when
// model is dropped in viewport, place origin under cursor
//
void ofApp::dragEvent(ofDragInfo dragInfo) {
    
    ofVec3f point;
    mouseIntersectPlane(ofVec3f(0, 0, 0), cam.getZAxis(), point);

	//Code to get Rover on mouse location
	ofVec3f mouse(mouseX, mouseY);
	ofVec3f rayPoint = cam.screenToWorld(mouse);
	ofVec3f rayDir = rayPoint - cam.getPosition();
	rayDir.normalize();
	Ray ray = Ray(Vector3(rayPoint.x, rayPoint.y, rayPoint.z),
		Vector3(rayDir.x, rayDir.y, rayDir.z));
	detectIntersection(ray, root);
	findRoverPosition();
	// point = selectedPoint;
	pts.clear();

    if (rover.loadModel(dragInfo.files[0])) {
        rover.setScaleNormalization(false);
        rover.setScale(.005, .005, .005);
		fixedRover = point;
        // rover.setPosition(point.x, point.y, point.z);
		cout << "Rover Position: " << rover.getPosition() << "\n";
		ofVec3f min = 0.005 * rover.getSceneMin();
		ofVec3f max = 0.005 * rover.getSceneMax();
		//ofVec3f min = point - 0.005 * rover.getSceneMin();
		//ofVec3f max = point - 0.005 * rover.getSceneMax();
		//diff = min.z - point.z;
		//cout << "Diff: " << diff << "\n"; 
		//min.z = min.z + diff;
		//max.z = max.z + diff;
		cout << "Min: " << min << "\n";
		cout << "Max: " << max << "\n";
		
		roverBound.parameters[0] = Vector3(min.x, min.y, min.z);
		roverBound.parameters[1] = Vector3(max.x, max.y, max.z);
        bRoverLoaded = true;
		bRoverSelected = true;
		startPath.addVertex(rover.getPosition());
    }
    else cout << "Error: Can't load model" << dragInfo.files[0] << endl;
}

bool ofApp::mouseIntersectPlane(ofVec3f planePoint, ofVec3f planeNorm, ofVec3f &point) {
    ofVec2f mouse(mouseX, mouseY);
    ofVec3f rayPoint = cam.screenToWorld(mouse);
    ofVec3f rayDir = rayPoint - cam.getPosition();
    rayDir.normalize();
    return (rayIntersectPlane(rayPoint, rayDir, planePoint, planeNorm, point));
}

