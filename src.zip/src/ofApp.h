#pragma once

#include "ofMain.h"
#include  "ofxAssimpModelLoader.h"
#include "box.h"
#include "ray.h"
#include "Octree.h"
#include "ofxGui.h"

class ofApp : public ofBaseApp{
    
public:
    void setup();
    void update();
    void draw();
    
    void keyPressed(int key);
    void keyReleased(int key);
    void mouseMoved(int x, int y );
    void mouseDragged(int x, int y, int button);
    void mousePressed(int x, int y, int button);
    void mouseReleased(int x, int y, int button);
    void mouseEntered(int x, int y);
    void mouseExited(int x, int y);
    void windowResized(int w, int h);
    void dragEvent(ofDragInfo dragInfo);
    void gotMessage(ofMessage msg);
    void drawAxis(ofVec3f);
    void initLightingAndMaterials();
    void savePicture();
    void toggleWireframeMode();
    void togglePointsDisplay();
    void toggleSelectTerrain();
    void setCameraTarget();
    bool doPointSelection();
    void drawBox(const Box &box);
    Box meshBounds(const ofMesh &);
    void subdivideTree(Octree* node);
    void displayTree(Octree* head);
	void detectIntersection(Ray r, Octree* node);
	void findRoverPosition();
	void switchPerspective();
	void saveToFile();

	ofBuffer buffer;
    
    bool mouseIntersectPlane(ofVec3f planePoint, ofVec3f planeNorm, ofVec3f &point);
	void sortPoints();
	float threshold = 3.0;
    void createOctree();
    
    ofEasyCam cam;
	ofEasyCam roverCam, backCam, frontCam, followCam;
    ofxAssimpModelLoader mars, rover;
    ofLight light;
	Box boundingBox, roverBound;
    vector<Box> level1, level2, level3, level4;
	int camera = 0;
    bool bAltKeyDown;
    bool bCtrlKeyDown;
    bool bWireframe;
    bool bDisplayPoints;
    bool bPointSelected;
	bool bShiftKeyDown;
	ofVec3f RoverLocation;
	ofVec3f rToMin;
	ofVec3f rToMax;
	ofVec3f oldRoverPosition;
    
    bool bRoverLoaded;
    bool bTerrainSelected;
	bool bRoverSelected;
	bool bExistingPointSelected = false;
	bool bDeletePointSelected = false;
	bool bPlay = false;
	bool bMoveRoverToStart = false;
	bool bRetargetCamera;
	int roverIndex = 0;
	ofxPanel gui;
	ofxIntSlider speedSlider;
	float angle;
    
    ofVec3f selectedPoint;
	ofVec3f intersectPoint;
	ofVec3f RoverPosition;
	ofVec3f ExistingPoint;
	ofVec3f DeletePoint;

	int ExistingPointIndex = -1;
	int DeletePointIndex = -1;

	// bool bPointSelected = false;
	int numOfBoxes = 0;
    
    const float selectionRange = 10.0;
	vector<ofVec3f> pts;
	vector<ofVec3f> polylinePoints;
	vector<Box> pathBoxes;
	ofPolyline path;
	ofPolyline startPath;
    Octree* root;
    Octree* cur;
    vector<ofVec3f> pointsList;
	vector<Box> boxList;
	int levelCounter = 0;
	ofVec3f cameraTarget;
	// ofPath p = ofPath();
	// ofVec3f startVec;
	ofVec3f fixedRover;
	float diff;
	ofVec3f frontCamLookAt, backCamLookAt, frontCamPosition, backCamPosition;
	bool bDisplayCoordinates = false;

};
